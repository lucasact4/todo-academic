package br.ufrpe.todoacademic.model;

// Estados possíveis de uma tarefa ao longo do fluxo
public enum StatusTarefa {
    PENDENTE,
    EM_ANDAMENTO,
    CONCLUIDA;
}
