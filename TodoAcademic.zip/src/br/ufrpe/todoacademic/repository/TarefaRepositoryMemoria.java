package br.ufrpe.todoacademic.repository;

import br.ufrpe.todoacademic.exception.RepositoryException;
import br.ufrpe.todoacademic.model.Tarefa;

import java.util.ArrayList;
import java.util.List;

// Implementação em memória do repositório de tarefas
public class TarefaRepositoryMemoria implements TarefaRepository {

    // armazenamento em memória usando lista simples
    private final List<Tarefa> tarefas = new ArrayList<>();
    // controle de id incremental (simulando auto incremento de banco)
    private int proximoId = 1;

    @Override
    public synchronized void adicionar(Tarefa tarefa) throws RepositoryException {
        if (tarefa == null) {
            throw new RepositoryException("Tarefa não pode ser nula");
        }
        tarefa.setId(proximoId++);
        tarefas.add(tarefa);
    }

    @Override
    public synchronized void atualizar(Tarefa tarefa) throws RepositoryException {
        if (tarefa == null) {
            throw new RepositoryException("Tarefa não pode ser nula");
        }
        int indice = encontrarIndicePorId(tarefa.getId());
        if (indice == -1) {
            throw new RepositoryException("Tarefa com id " + tarefa.getId() + " não encontrada");
        }
        tarefas.set(indice, tarefa);
    }

    @Override
    public synchronized void remover(int id) throws RepositoryException {
        int indice = encontrarIndicePorId(id);
        if (indice == -1) {
            throw new RepositoryException("Tarefa com id " + id + " não encontrada");
        }
        tarefas.remove(indice);
    }

    @Override
    public synchronized Tarefa buscarPorId(int id) throws RepositoryException {
        for (Tarefa t : tarefas) {
            if (t.getId() == id) {
                return t;
            }
        }
        throw new RepositoryException("Tarefa com id " + id + " não encontrada");
    }

    @Override
    public synchronized List<Tarefa> listarTodas() {
        // devolve cópia para não expor a lista interna
        return new ArrayList<>(tarefas);
    }

    @Override
    public synchronized List<Tarefa> buscarPorResponsavel(String responsavel) {
        List<Tarefa> resultado = new ArrayList<>();
        if (responsavel == null) {
            return resultado;
        }
        for (Tarefa t : tarefas) {
            if (t.getResponsavel() != null &&
                t.getResponsavel().equalsIgnoreCase(responsavel)) {
                resultado.add(t);
            }
        }
        return resultado;
    }

    // busca a posição da tarefa na lista pelo id
    private int encontrarIndicePorId(int id) {
        for (int i = 0; i < tarefas.size(); i++) {
            if (tarefas.get(i).getId() == id) {
                return i;
            }
        }
        return -1;
    }
}
